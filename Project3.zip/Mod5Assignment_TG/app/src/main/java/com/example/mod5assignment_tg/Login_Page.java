package com.example.mod5assignment_tg;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class Login_Page extends AppCompatActivity {


    EditText textEmailAddress, textPassword;
    Button login_button, forgot_pass_button, register_button;
    CheckBox checkbox;
    ImageView google_icon, facebook_icon;
    SQLDb GordonDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_login);

        textEmailAddress = (EditText) findViewById(R.id.textEmailAddress);
        textPassword = (EditText) findViewById(R.id.textPassword);
        login_button = (Button) findViewById(R.id.login_button);
        forgot_pass_button = (Button) findViewById(R.id.forgot_pass_button);
        register_button = (Button) findViewById(R.id.register_button);
        checkbox = (CheckBox) findViewById(R.id.checkbox);
        google_icon = (ImageView) findViewById(R.id.google_icon);
        facebook_icon = (ImageView) findViewById(R.id.facebook_icon);
        GordonDB = new SQLDb(this);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login_Page.this, Register_Page.class);
                startActivity(intent);
            }

        }

        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String textEmailAddress = textEmailAddress.getText().toString();
            String textPassword = textPassword.getText().toString();

            if (GordonDB.checkusernamepassword(textEmailAddress, textPassword) == false) {
                boolean insert = GordonDB.insertData(textEmailAddress, textPassword);
                if (insert == true) {
                    Toast.makeText(Login_Page.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Login_Page.this, "Registration Failed, please try a different username", Toast.LENGTH_SHORT).show();
                }
            }
            }
        }

    }


}



