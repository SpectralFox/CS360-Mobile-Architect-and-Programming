package com.example.mod5assignment_tg;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLDb extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Inventory.db";

    public SQLDb(Context context) {
        super(Inventory, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase GordonDB) {
        GordonDB.execSQL("create Table users(username TEXT primary key, password TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase GordonDB, int oldVersion, int newVersion) {
        GordonDB.execSQL("drop Table if exists users");

    }

    public Boolean insertData (String textEmailAddress, String textPassword) {
        SQLiteDatabase GordonDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", textEmailAddress);
        contentValues.put("password", textPassword);
        long result = GordonDB.insert("users", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean checkusername (String textEmailAddress) {
        SQLiteDatabase GordonDB = this.getWritableDatabase();
        Cursor cursor = GordonDB.rawQuery("Select * from users where username = ?", new String[]{textEmailAddress});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean checkusernamepassword(String textEmailAddress, String textPassword) {
        SQLiteDatabase GordonDB = this.getWritableDatabase();
        Cursor cursor = GordonDB.rawQuery("Select * from users where username = ? and password = ?", new String[]{textEmailAddress, textPassword});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

}
