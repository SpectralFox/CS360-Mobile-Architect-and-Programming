package com.example.mod5assignment_tg;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.BreakIterator;

public class Login_Page extends AppCompatActivity implements TextWatcher{

    EditText nameText;
    TextView textGreeting;

    //private BreakIterator text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_login);
        nameText = findViewById(R.id.editTextTextEmailAddress);
        textGreeting = findViewById(R.id.AppHeading);

    }
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    public void openDatabase_Page(View view) {
        startActivity(new Intent(this, Database_Page.class ));
    }
    /* public void afterTextChanged(Editable s) {
        if (nameText.getText().toString().matches(""))
            buttonSayHello.setEnabled(false);
        else
            buttonSayHello.setEnabled(true);
    }

    public void SayHello(View view) {
        if (!nameText.getText().toString().matches("")) {
            text.setText("Hello, " + nameText.getText());
        } else {
            textGreeting.setText("Please enter your name");
        }
    }
*/
}